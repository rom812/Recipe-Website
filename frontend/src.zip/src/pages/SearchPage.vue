<template>
    <div class="container">
      <h1 class="title">Search Page</h1>
    </div>
  </template>
  